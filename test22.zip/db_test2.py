from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
# from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.orm import sessionmaker
from db_structures import Paikka

"""
engine = create_engine('sqlite:///test//test14.db', echo=False)
Session = sessionmaker(bind=engine)
session = Session()
Base = declarative_base()
"""


# Connect to the database using SQLAlchemy
engine = create_engine('sqlite:///test//test20.db', echo=False)
Session = sessionmaker()
Session.configure(bind=engine)

session = Session()
Base = declarative_base()
Base.metadata.create_all(engine)

kysyttypaikka = session.query(Paikka)\
    .filter(Paikka.lyhytnimi == "TA181210555").all()
print(kysyttypaikka)
