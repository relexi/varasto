from create_varasto_sql import create_string
import sqlite3
from sqlite3 import Error

from sqlalchemy import create_engine
from db_structures import Paikka
from sqlalchemy.orm import sessionmaker


str_db_file = "test22.db"
# Hylly parametrit
hyllyt = {"A": [3, 5, [3, 3, 4]],
          "B": [3, 3, [3, 3, 3]],
          "C": [3, 3, [3, 3, 3]],
          "D": [3, 3, [3, 3, 3]],
          "E": [2, 4, [4, 4]]}


def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by the db_file
    :param db_file: database file
    :return: Connection object or None
    """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
    return conn


def add_paikka(session, hylly, vali, taso, lava):
    """
    this function adds a new row into the table paikka
    and sets its status active = 0

    parameters: session (db-connection), hylly (String), taso (Integer),
    vali (Integer), lava (Integer)
    """

    lyhytnimi = hylly + str(vali) + str(taso) + str(lava)
    onko = session.query(Paikka.lyhytnimi)\
        .filter(Paikka.lyhytnimi == lyhytnimi).all()
    if onko != []:
        print(lyhytnimi + " on jo olemassa")
    else:
        paikka = Paikka(lyhytnimi=lyhytnimi, hylly=hylly, vali=vali, taso=taso,
                        lava=lava, active=0)
        print(paikka.paikka_id, paikka.lyhytnimi)
        session.add(paikka)


# create new db-file
conn = create_connection(f"test\\{str_db_file}")
crsr = conn.cursor()
for query in create_string():
    crsr.execute(query)


# connect to the database through SQLAlchemy
engine = create_engine(f'sqlite:///test//{str_db_file}', echo=False)
Session = sessionmaker()
Session.configure(bind=engine)
session = Session()


for hylly, elem in hyllyt.items():
    valit = hyllyt[hylly][0]
    tasot = hyllyt[hylly][1]
    lavat = hyllyt[hylly][2]

    for vali in range(valit):
        for t in range(tasot):
            taso = tasot-t-1
            for lava in range(lavat[vali]):
                add_paikka(session, hylly, vali, taso, lava)

session.commit()
